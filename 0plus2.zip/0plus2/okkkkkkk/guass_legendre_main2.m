clear all
clc
tic
%主程序：验证球谐函数正逆变换
BNC=16;%[0,BNC]is the range of l in spherical harmonics,that is,(BNC+1)*(BNC+2)/2 is the number of spherical harmonics
N2C=BNC;%BNC;%number of sita[o,pi]
N1=BNC+1;
N3C=2*N2C+1;%2*BNC+1;%N3C is the numer of phi [0,2*pi]
[YPlm,Y_star]=prepare(N1,BNC,N3C,N2C);
qq=zeros(N2C,N3C);
gauss=get_gaussian(N2C);
 theta=acos(gauss(:,1));
 phi=(2*pi/(N3C)*(0:N3C-1))';
 %load testing1.mat
cossita=zeros(N2C,1);sinsita=zeros(N2C,1);cosphi=zeros(N3C,1);sinphi=zeros(N3C,1);
for i=1:N2C
    if i<=(N2C+1)/2
        cossita(i)=gauss(i,1);
    else
        cossita(i)=-gauss(N2C+1-i,1);
    end
    sinsita(i)=sqrt(1-cossita(i)*cossita(i));
end
  % size(sinsita)
    cosphi=cos(2*pi/(N3C)*(0:N3C-1))';
	sinphi=sin(2*pi/(N3C)*(0:N3C-1))';


  %qq=ones(BNC,1)*sin(2*pi*rand(1,N3C));%给定的球谐函数g(sita,phi)
  
%   k=1;
%   for i=1:N2C
%      for j=1:N3C
%          qq(i,j)=cos(k*(sinsita(i)*cosphi(j)+sinsita(i)*sinphi(j)+cossita(i)));
%          %qq(i,j)=sinphi(j)^2;
%          %qq(i,j)=sin(20*(sinsita(i)*cosphi(j)))*sin(20*((sinsita(i)*sinphi(j))))*sin(20*(cossita(i)));
%          %qq(i,j)=sinsita(i)*sinphi(j);
%      end
%   end
l1=5;
m1=3;
 F1(:,:)=Y_star((l1-1)*l1/2+m1,:,:,1);
 l2=5;
 m2=5;
 F2(:,:)=Y_star((l2-1)*l2/2+m2,:,:,1);
 F=F1+F2;
% for i=1:N2C
%     for j=1:N3C
% F(i,j)=spherical_harmonic(N1,BNC,l,m,cossita(i))*cosphi(j);
%     end
% end  
%size(F)
disp(F);
 load testing1.mat
 F=U;
  %         qq=cossita;%给定的球谐函数g(sita,phi)
%            qq(i,j)=sin((asin(sinsita(i))+phi(j)));
%   
qy=real2spherical_r2c(N1,N3C,BNC,N2C,F);%固定sita,对球谐函数g(sita,phi)傅里叶变换，g(lm)
qq1=spherical2real_c2r(N1,N3C,BNC,N2C,qy);%固定sita,对球谐函数g(sita,phi)逆傅里叶变换，g(sita,phi)*
fprintf('误差\n\n\n');
disp(F-qq1)
%disp(qq1);%球谐函数正逆变换误差
%plot(qq1)
%for i=1:N2C
%	fprintf('%6.9f\n',gauss(i,1));
%end

%�޸�
% Apply spherical coordinate equations
%r = rho.*repmat(sinsita,1,N2C);
r=1;
for i=1:N2C
    for j=1:N3C
x_mm(i,j)=sinsita(i,1)*cosphi(j,1);
y_mm(i,j)=sinsita(i,1)*sinphi(j,1);
z_mm(i,j)=cossita(i,1);

    end
end
% i
% size(x_mm)
% size(Y)
% Plot the surface
clf
surf(x_mm,y_mm,z_mm,real(qq1))
%light
colorbar%%%�޸�
shading interp;%%�޸�
%lighting phong
%axis tight equal off
%view(40,30)
%camzoom(1.5)
% 


toc