%通过IFFT求g(sita,phi)*
function qB=spherical2real_c2r(N1,N3C,BNC,N2C,qy)	
comp=zeros(2,N3C);
c=zeros(1,BNC+1);
qB=zeros(N2C,N3C);
[YPlm,Y_star]=prepare(N1,BNC,N3C,N2C);%调用除e^(im*phi)外的Y_lm(sita,phi),即h(sita)
for i=1:N2C
    for m=1:BNC+1
         comp(1,m)=0;
         comp(2,m)=0;
         l=BNC+1;
         while l>=m
             temp1=YPlm(((l-1)*l/2+m),i);
             %fprintf('%.9f ',temp1);
             p=qy(l,m+BNC);
             %fprintf('%6.9f ',real(p));
             comp(1,m)=comp(1,m)+real(p)*temp1;
             
             comp(2,m)=comp(2,m)+imag(p)*temp1;
           l=l-1;
         end        
           c(m+BNC)=complex(comp(1,m),comp(2,m));%求m>=0时逆傅里叶（IFFT）系数
           %fprintf('%.9f',c(m+BNC));
          % fprintf('\n');
    end 

    for m=2:BNC+1  
         l=m;
         %mm=N3C+2-m;
         comp(1,m)=0;
         comp(2,m)=0;
         while l<=BNC+1
             temp1=power(-1,m-1)*YPlm((l-1)*l/2+m,i);
             p=qy(l,BNC-m+2);
             %fprintf('%.9f ',real(p));   %%%%% g_lm放对了
             %fprintf('%.9f ',temp1)  %%%YPlm放对了.
             comp(1,m)=comp(1,m)+real(p)*(temp1);
              %fprintf('%.9f ',complex(1,m));
              comp(2,m)=comp(2,m)+imag(p)*(temp1);
           % fprintf('%.9f ',comp(1,m));
                 
           l=l+1;
         end        
           c(BNC+2-m)=complex(comp(1,m),comp(2,m));  %求m>=0时逆傅里叶（IFFT）系数
          % fprintf('\n');
    end 
    %fprintf('%.9f\t',c)
    %fprintf('\n');%%%%%%%%%%%c也计算正确.
    
    
    for k=1:2*BNC+1
        if k<=BNC
            c0(k+BNC+1)=c(k);
        else 
            c0(k-BNC)=c(k);
        end
    end
 %fprintf('%.9f\t',c0)
% fprintf('\n');%%%%%%%%%%%c也计算正确.
    
    
    real_t=ifftn(c0)*(N3C);%通过IFFT求g(sita,phi)*
    %fprintf('%.9f ',real_t);
    %fprintf('\n');
    for k=1:2*BNC+1
        qB(i,k)=real_t(k);
    end
   
    
end


              
        
            

             
				
			        
         
			
			
