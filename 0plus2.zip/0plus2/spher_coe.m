function coeff_mn=spher_coe(g,degree,order,pairs,theta,phi)
[Ymn_p,Ymn_op,Y_star_p,Y_star_op,Y_p,Y_op]=spher_harmonic(degree,abs(order),theta,phi);
if order<0
    Y=Y_op;
else
    Y=Y_p;
end
[cow,dim]=size(g);
%%%对初始函数ｇ做傅里叶变换，求其系数
coeff_mn=zeros(cow,dim);
for k=1:cow
    g_k(k,:)=fft(g(k,:));  
end
%for i=1:cow
for j=1:dim
if j==order
    coeff_mn=Y'*repmat((g_k(:,j).*pairs(:,2)),1,dim);
else
    break;
end
coeff_mn
end
    
    