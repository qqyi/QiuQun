function spher_harmonic_tbl=sph_tbl(degree,theta,phi)
spher_harmonic_tbl=zeros(length(theta),length(phi),degree+1,2*degree+1);
[phi,theta]=meshgrid(phi,theta);
for n=1:degree+1
    for m=-n+1:1:n-1  
        if m>=0
[Ymn_p,Ymn_op,Y_star_p,Y_star_op,Y_p,Y_op]=spher_harmonic(n-1,abs(m),theta,phi);
spher_harmonic_tbl(:,:,n,m+degree+1)=Y_star_p;
        else
[Ymn_p,Ymn_op,Y_star_p,Y_star_op,Y_p,Y_op]=spher_harmonic(n-1,abs(m),theta,phi);
spher_harmonic_tbl(:,:,n,m+degree+1)=Y_star_op;
        end
    end
end