function coeff_tbl=sph_coe_tbl(g,degree,pairs,theta,phi)
[cow,dim]=size(g);
coeff_tbl=zeros(cow,dim,degree+1,2*degree+1);
for n=1:degree+1
    for m=-n+1:1:n-1
coeff_tbl(:,:,n,m+degree+1)=spher_coe(g,n-1,m,pairs,theta,phi);
    end
end


