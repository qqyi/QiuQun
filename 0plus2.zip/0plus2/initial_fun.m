function g=initial_fun(coeff_tbl,sph_tbl)
[d1,d2,d3,d4]=size(sph_tbl);
mulp=coeff_tbl.*sph_tbl;
for theta_n=1:d1
    for phi_n=d2
        g(theta_n,phi_n)=sum(sum(mulp(theta_n,phi_n,:,:)));
    end
end

