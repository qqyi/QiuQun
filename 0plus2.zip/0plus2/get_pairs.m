%求区间[-1,1]上的高斯点和高斯权重
function  pairs=get_pairs(n)

pairs=zeros(n,2);

if rem(n,2)==1
    m=(n+1)/2;
else
    m=n/2;
end
    [x,w]=GaussPairs(n);
	
    for i=1:m
	    pairs(n+1-i,1)=x(m-i+1);%[0,1]上的高斯点
	    pairs(i,1)=-x(m-i+1);%[-1,0]上的高斯点
            pairs(n+1-i,2)=w(m-i+1);%[0,1]上的高斯权重
            pairs(i,2)=w(m-i+1);  %[-1,0]上的高斯权重    
	end
	
end
