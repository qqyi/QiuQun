function [Ymn_p,Ymn_op,Y_star_p,Y_star_op,Y_p,Y_op]=spher_harmonic(degree,order,theta,phi)
% degree=5;
% order=4;
% delta = pi/40;
% theta = 0 : delta : pi; % altitude
% phi = 0 : 2*delta : 2*pi; % azimut

[phi,theta]=meshgrid(phi,theta);
Pmn_tbl= legendre(degree,cos(theta(:,1)));%%%%%��һ����Ҳ���Բ������һ����ԭʼ��ʽ
[row,dim]=size(Pmn_tbl);
%Pmn = Pmn_tbl(order+1,:);
Pmn = Pmn_tbl(order+1,:)';
Pmn_p = Pmn;
for kk = 2: size(theta,1)
    Pmn_p = [Pmn_p Pmn];
end;

exp_phi=complex(cos(order*phi),sin(order*phi));
exp_phi_op=complex(cos(-order*phi),sin(-order*phi));
%Ymn_p = Ymn_p.*cos(order*phi);
Ymn_p=Pmn_p.*exp_phi;
%%%%%m>=0时球调和函数的表达式

% Pmn=Pmn_tbl;
% sph_p=Pmn(2:end,:);
Ymn_op=(-1).^(order)*factorial(degree-order)./factorial(degree+order).*Ymn_p;%%%m<0时spherical harmonic function
Y_star_p=(-1).^order.*Ymn_op;
Y_p=Y_star_p.*exp_phi_op;
Y_star_op=(-1).^(-order).*Ymn_p;
Y_op=Y_star_op.*exp_phi;
%Pmn=[Ymn_op Pmn];
% m=(0:degree)';
% M_phi=cos(m*phi);
% for i=1:size(m)
% theta_phi(:,:,i)=Pmn_tbl(i,:)'*M_phi(i,:);
% end
% 
% exp_phi_p=complex(repmat(cos(order*phi)',1,length(phi)),repmat(sin(order*phi)',1,length(phi)));
% Y_star_p=sph_p.*exp_phi_p;
% Y_star_op=Y_star_p(2:end,:)'.*repmat(repmat([-1,1]',(row-1)/2,1),1,dim);
% Y_star=[flipud(Y_star_op.');Y_star_p];
end

