%% CONVERGENCE OF FAST SOLVERS FOR MIXED FINITE ELEMENT METHOD (RT0-P0) FOR DARCY'S EQUATIONS
%
% This example is to show the convergence of fast solvers of mixed finite
% element (RT0-P0) approximation of the Darcy's equations.
%

close all

%% Setting
[node,elem] = squaremesh([0,1,0,1],0.25); 
% option.L0 = 1;
option.maxIt = 4;
option.printlevel = 1;
option.elemType = 'RT0';
option.refType = 'red';
% option.solver = 'uzawapcg';
option.solver = 'tri';
% option.solver = 'mg';

%% Poisson
pde = Darcydata0;
display('Poisson: uniform grid')
bdFlag = setboundary(node,elem,'Neumann');
mfemDarcy(node,elem,pde,bdFlag,option);

%% Anisotropic tensor
display('Anisotropic tensor: uniform grid')
[node,elem] = squaremesh([0,1,0,1],0.25); 
pde = Darcydata4;
option.dquadorder = 3;
bdFlag = setboundary(node,elem,'Neumann');
mfemDarcy(node,elem,pde,bdFlag,option);

%% Jump tensor
display('Jump tensor: uniform grid')
pde = Darcydata3;
bdFlag = setboundary(node,elem,'Neumann');
mfemDarcy(node,elem,pde,bdFlag,option);

%% Jump tensor with distortion of grids
display('Jump tensor: distorted grid')
% perturbe the grid
[bdNode,bdEdge,isBdNode] = findboundary(elem);
isIntNode = ~isBdNode;
node(isIntNode,:) = node(isIntNode,:) + 0.25*0.4*rand(sum(isIntNode),2);
pde = Darcydata3;
bdFlag = setboundary(node,elem,'Neumann');
mfemDarcy(node,elem,pde,bdFlag,option);
