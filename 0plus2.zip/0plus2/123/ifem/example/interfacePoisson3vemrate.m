clear all; close all;
cube = [-2, 2, -2, 2, -2, 2];
pde = twosphereinterfacedata(0.5, 1, 1);
option.solver = 'amg';
option.h0 = 0.2;
option.maxIt = 4;

vemInterfacePoisson3(cube, pde, option)
