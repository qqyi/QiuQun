%% Set path to iFEM  
%
% Add all subdirectories under pathstr to search path.
%
% Copyright (C) Long Chen. See COPYRIGHT.txt for details. 

addpath(genpath(pwd),'-begin');
savepath;