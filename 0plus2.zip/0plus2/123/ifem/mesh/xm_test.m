load airfoilperturbmesh
showmesh(node,elem)
meshquality(node,elem);
elem = edgeswap(node,elem);
showmesh(node,elem)
meshquality(node,elem);

