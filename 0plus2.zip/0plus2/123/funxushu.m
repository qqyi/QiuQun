%定义复数
function c=funxushu(a,b)
c=a+b*1i;
end
