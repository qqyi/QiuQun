clear all
tic

load sph-cly-test2-5.mat
%load sph-cly-test2-4.mat
%load sph-cly-test1-7.mat


nrows = 16;
ncols = 2*nrows+1;
rk=5;
% X = linspace(0,360, ncols);
% Y = linspace(-90,90, nrows);
% X = linspace(0,2*pi, ncols);
% Y = linspace(-pi/2,pi/2,nrows );
%Y=[1.2880,0.9218,0.5533,0.1845,-0.1845,-0.5533,-0.9218,-1.2880]
gauss=get_gaussian(nrows);
Y=acos(gauss(:,1))'-pi/2;
X=linspace(-pi,pi,ncols);
%Y = linspace(-pi/2,pi/2, nrows);%%%修改
[lon, lat] = meshgrid(X,Y);%lon ����
% Convert to radians and make longitude measured "westwards" (-ve sign)
% lon = -lon*pi/180;
 %lat = lat*pi/180;
% lon = lon*pi/180;
% lat = lat*pi/180;

 

[theta, phi, R] = cart2sph(init_mesh.node(:, 1), init_mesh.node(:, 2), init_mesh.node(:, 3));
%F = scatteredInterpolant([theta, phi], scft.rho(1, :)', 'nearest', 'nearest');
F = scatteredInterpolant([theta, phi], scft.rho(1, :)', 'natural', 'nearest');

U = F(lon, lat);
size(U)
save('/home/aaa/Documents/0plus2/testing1.mat','U')
%save /home/aaa/梁琴老师Ｃ语言代码/chuzhi.txt -ascii U;
 %save /home/aaa/123/chuzhi.txt -ascii U;
%save('/home/aaa/Desktop/spherical harmonic code 2/chuzhi.mat','U') 
%save('/home/aaa/Documents/MATLAB-解Cahn-Hilliard equation/Spherical-Harmonic-Transform-master/Eg.mat','U')
% %  U=zeros(N2C+2,N3C+1);
% %  U(2:N2C+1,N3C+1)=U1(1:N2C,1);
% %  U(2:N2C+1,1:N3C)=U1(1:N2C,1:N3C);
% %  U(1,:)=mean(U(2,:));
% %  U(N2C+2,:)=mean(U(N2C+1,:));


% gauss=get_gaussian(N2C);
% %cossita=zeros(N2C,1);sinsita=zeros(N2C,1);cosphi=zeros(N3C,1);sinphi=zeros(N3C,1);
% psi=(2*pi/(N3C))*(0:(N3C));
% the=acos(gauss(:,1));
% the=[pi the' 0]';
% [psi,the]=meshgrid(psi,the);

rpol=rk*ones(size(lat));
z_mm=rpol.*sin(lat);%*1000;                     % z in transformational relation;
x_mm=rpol.*cos(lat).*cos(lon);%*1000;           % x in transformational relation;
y_mm=rpol.*cos(lat).*sin(lon);%*1000;           % y in transformational relation;
%plot3(x_mm,y_mm,z_mm)
surf(x_mm,y_mm,z_mm,U);

shading interp;%light;lighting gouraud;

colorbar
%saveas(gcf,'myfig.png');
axis equal;

xlabel('x(mm)');ylabel('y(mm)');zlabel('z(mm)');

toc