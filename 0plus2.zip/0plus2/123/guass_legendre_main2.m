%主程序：验证球谐函数正逆变换
clear all;
clc;
load chuzhi.mat;
[col,dim]=size(U);

BNC=16;%[0,BNC]is the range of l in spherical harmonics,that is,(BNC+1)*(BNC+2)/2 is the number of spherical harmonics
N2C=BNC;%number of sita[o,pi]
N1=BNC+1;
N3C=2*N2C+1;%N3C is the numer of phi [0,2*pi]
%N3C=dim;
YPlm=prepare(N1,BNC,N3C,N2C);
qq=zeros(N2C,N3C);
gauss=get_gaussian(N2C);
a=acos(gauss(:,1))-pi/2;
cossita=zeros(N2C,1);sinsita=zeros(N2C,1);cosphi=zeros(N3C,1);sinphi=zeros(N3C,1);
for i=1:N2C
    if i<=(N2C+1)/2
        cossita(i)=gauss(i,1);
    else
        cossita(i)=-gauss(N2C+1-i,1);
    end
    sinsita(i)=sqrt(1-cossita(i)*cossita(i));
end
for j=1:N3C    
    cosphi(j)=cos(2*pi/(N3C)*(j-1));
	sinphi(j)=sin(2*pi/(N3C)*(j-1));
end
for i=1:N2C
    for j=1:N3C
        %qq(i,j)=sinsita(i)*sin(cossita(i)*cosphi(j))*sin(cossita(i)*sinphi(j));%给定的球谐函数g(sita,phi)
       qq(i,j)=sinsita(i);%给定的球谐函数g(sita,phi)

    end
end
%qq=ones(N2C,1)*cosphi';
%qq =( sinsita.*(cossita*sinphi'));
%disp(qq);
%qq=sin(cossita*cosphi').*sin(cossita*sinphi');
qq2=sinsita*cosphi';
qy=real2spherical_r2c(N1,N3C,BNC,N2C,qq);%固定sita,对球谐函数g(sita,phi)傅里叶变换，g(lm)
qq1=spherical2real_c2r(N1,N3C,BNC,N2C,qy);%固定sita,对球谐函数g(sita,phi)逆傅里叶变换，g(sita,phi)*
disp(qq1);
disp(qy);
size(qy)
disp(qq1-qq);%球谐函数正逆变换误差
%for i=1:N2C
%	fprintf('%6.9f\n',gauss(i,1));
%end
