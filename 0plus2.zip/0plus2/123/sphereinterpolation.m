% Create a longitude/latitude grid with 0.1 degree spacing
load sph-cly-test2-5.mat
% load heartsurface1.mat
nrows = 180;
ncols = 360;
X = linspace(-180,180, ncols);
Y = linspace(-90,90, nrows);
% X = linspace(0,2*pi, ncols);
% Y = linspace(0,pi, nrows);

[lon, lat] = meshgrid(X,Y);
% Convert to radians and make longitude measured "westwards" (-ve sign)
lon = -lon*pi/180;
lat = lat*pi/180;
% lon = -lon;



[theta, phi, R] = cart2sph(init_mesh.node(:, 1), init_mesh.node(:, 2), init_mesh.node(:, 3));
F = scatteredInterpolant([theta, phi], scft.rho(1, :)', 'nearest', 'nearest');
val = F(lon, lat);

% figure
% surf(lon, lat, val);
% axis equal 

figure
surface(lon, lat, val);
axis equal

figure
showsolution(init_mesh.node, init_mesh.elem, scft.rho(1, :));
axis equal
