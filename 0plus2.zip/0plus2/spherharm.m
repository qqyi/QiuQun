function y=spherharm(l,x1,x2)
%SPHERHARM Associated spherical harmonic function
% Y_l^m(\theta,\phi) = (-1)^m*sqrt{(2*l+1)/4/pi*(l-|m|)!/(l+|m|)!}
%                           *P_l^m(cos(\theta))*exp{i*m*\phi}
%

if numel(l) > 1 || ~isreal(l) || l < 0 || l ~= round(l)
    error('L must be a positive scalar integer');
end
% 
% if abs(m) > l
%     error('L must great than abs value of m');
% end

if size(x1) ~= size(x2)
    error('The size of X1 and X2 must be equal');
end

% The l=0 Case
if l==0
    y=ones(size(x1))/sqrt(pi)/2;
    y=y(:).';
    return
end

Ylm = legendre(l,cos(x1),'norm');
Ylm = Ylm/sqrt(2*pi);

y(l+1,:)=Ylm(1,:);
for m=1:l
    y(l+m+1,:)=(-1)^m*Ylm(m+1,:).*exp(i*m*x2(:)');
    y(l-m+1,:)=Ylm(m+1,:).*exp(-i*m*x2(:)');
end

% if argin==4
%     y=y(l+k+1,:);
% end