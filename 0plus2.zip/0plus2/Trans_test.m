%%%%%%%%%%%%%%%%%%%%%%%
%test
degree=8;
theta_n=degree;
phi_n=theta_n;
%pairs=get_pairs(theta_n-1);
%cos_theta=[pairs(:,1)' 1];
pairs=get_pairs(theta_n);
cos_theta=pairs(:,1)';
%size(pairs)
phi=linspace(0,2*pi,phi_n);
[phi_initial,cos_theta_initial]=meshgrid(phi,cos_theta);
%size(phi)
%size(cos_theta)
g=cos(phi_initial).*sin(cos_theta_initial);
%size(g)
coeff_tbl=sph_coe_tbl(g,degree,pairs,cos_theta,phi);